# CMPT 116/141 - Matryoshka Dolls

chest1 = {
    "Dafna" : ["Vera", "Lada", "Alla","Zoe"],
    "Yana" : ["Zoe"],
    "Vera" : ["Inga"],
    "Alla" : ["Zoe"]
}
chest2 = {
    "Dina" : ["Zlata","Olga"],
    "Erene" : ["Veronika","Olga","Zlata","Nina"],
    "Veronika" : ["Zlata","Olga"],
    "Zlata" : ["Olga"],
    "Tamara" : ["Olga"],
}

