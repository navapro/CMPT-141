# CMPT 116/141 -maplabeling

def intersection_2sq(s1,s2):
    """
    This function determines whether or not the two given squares intersect. The two
    squares are given by the integer coordinates of their lower left corner.
    Both squares have side length 2.
    Parameters: s1,s2: Each is a 2 by 2 square whose lower left corner coordinates
    is given as a tuple of two integers
    Returns Boolean: True if the two squares intersect, and False if they do not.
    """
    return s1[0]-1 <= s2[0] and s2[0] <= s1[0] + 1 and \
           s1[1] - 1 <= s2[1] and s2[1] <= s1[1] + 1

def intersection_inlist(test_square,List):
    """
    This function determines if a given test_square intersects with any of the squares
    in the given list of squares. All of the squares have side length 2.
    Parameter1 test_square:A 2 by 2 square whose lower left corner coordinates is
    given as a tuple of two integers
    Parameter2 List: A list of 2 by 2 squares whose lower left corner coordinates
    are given as a tuple of two integers
    Returns Boolean:  True is the test_square intersects with any of the squares
    in the given list of squares,
    False if there is no intersection.
    """
    for sq in List:
        if intersection_2sq(test_square,sq):
            return True
    return False

squarelist1 = [(-1,-1),(0,0),(1,1)]
squarelist2 = [(2,3),(6,8),(6,9),(9,1),(3,4),(2,4)]
squarelist3 = [(-3,0),(-2,1),(-1,2),(0,1),(1,0),(0,-1),(-1,-2),(-2,-1)]
